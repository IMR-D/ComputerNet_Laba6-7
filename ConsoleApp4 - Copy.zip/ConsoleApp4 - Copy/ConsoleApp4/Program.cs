﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
  
   

    class Program
    {
        static int n=10;
        public static List<string>Time ;
         
        // порт для приема входящих запросов
        static int port = 8005;
        static void Main(string[] args)
        {
            Time = new List<string>(); ;
            // получаем адреса для запуска сокета
            IPEndPoint IpPoint = new IPEndPoint(IPAddress.Parse("192.168.0.103"), port);
            // создаем сокет
            Socket listenSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                listenSocket.Bind(IpPoint);
                listenSocket.Listen(10);
                Console.WriteLine("Сервер запущен. Ожидание подключений...");
                while (true)
                {
                    Socket handler = listenSocket.Accept();;
                    Console.WriteLine("Произошло соединение с "+ IPAddress.Parse(((IPEndPoint)handler.RemoteEndPoint).Address.ToString())+ " IP адресом");
                    Console.WriteLine("TimeOut для соединения = "+ n +"мс.");
                    // получаем сообщение
                    StringBuilder builder = new StringBuilder();
                    int bytes = 0; // количество полученных байтов
                    int packet = 0; // количество полученных пакетов
                    byte[] data = new byte[256]; // буфер для получаемых данных
                    var stopwatch = new Stopwatch(); 
                    var stopwatch2 = new Stopwatch();
                    
                    do
                    {
                        stopwatch2.Start();
                        stopwatch.Start();
                        bytes = handler.Receive(data);
                        builder.Append(Encoding.Unicode.GetString(data, 0, bytes));
                        if (stopwatch.ElapsedMilliseconds > n)
                        {
                            stopwatch.Stop();
                            break;
                        }
                        stopwatch.Stop();
                        packet++;
                        Console.WriteLine("Получено от "+ IPAddress.Parse(((IPEndPoint)handler.RemoteEndPoint).Address.ToString()) + " пакет = " + data.Length + " байт" + " время = "+ stopwatch.ElapsedMilliseconds + "мс");
                        

                    }
                    while (handler.Available > 0);
                    stopwatch2.Stop();
                   
                    Console.WriteLine("Статистика по  " + IPAddress.Parse(((IPEndPoint)handler.RemoteEndPoint).Address.ToString()) + " :"); 
                    Console.WriteLine("Пакетов получено = "+ packet +" общий размер пакета = "+ builder.Length * sizeof(char) + " байт или " + builder.Length * sizeof(char)/1024 +" Кбайт" + " затраченное время = " + stopwatch2.ElapsedMilliseconds + "мс");
                    Console.WriteLine("Время получения "+DateTime.Now.ToShortTimeString() + "\nСодержимое пакета: " + builder.ToString());
                    Console.WriteLine("");
                    Time.Add(Convert.ToString(stopwatch2.ElapsedMilliseconds));
                    n++;
                    handler.Shutdown(SocketShutdown.Both);
                    handler.Close();
                    //foreach (string time in Time)
                        //Console.WriteLine(time);
                }
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
