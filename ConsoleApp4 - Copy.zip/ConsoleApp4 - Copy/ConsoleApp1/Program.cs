﻿using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Diagnostics;

namespace SocketTcpClient
{
    class Program
    {
        static int n = 0;
        // адрес и порт сервера, к которому будем подключаться
        static int port = 8005; // порт сервера
        static string address = "192.168.0.103"; // адрес сервера
        static void Main(string[] args)
        {
            try
            {
            send:
                IPEndPoint ipPoint = new IPEndPoint(IPAddress.Parse(address), port);
                Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                StringBuilder builder = new StringBuilder();
                // подключаемся к удаленному хосту
                
                socket.Connect(ipPoint);
              
                string message = "asd";
                message = string.Format("[{0}]", message.PadRight(12286, '_'));
                byte[] data = Encoding.Unicode.GetBytes(message);
                socket.Send(data);

                // получаем ответ
                data = new byte[256]; // буфер для ответа
                int bytes = 0; // количество полученных байт

                do
                {
                    bytes = socket.Receive(data, data.Length, 0);
                }
                while (socket.Available > 0);
                // закрываем сокет
                socket.Shutdown(SocketShutdown.Both);
                socket.Close();
                if (n < 10)
                {
                    n++;
                    goto send;
                } 
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.Read();
        }
    }
}